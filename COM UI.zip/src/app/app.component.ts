import { Component, OnInit, OnDestroy } from '@angular/core';
import { UserService, UserServiceConfig, User, PGConfigService } from 'pg-app-core';
import { COMStateService, System } from 'pg-com-core';
import { Message } from 'pg-primeng/primeng';
import { COMMessageService, COMMessageSeverity} from 'pg-com-core';
import { Subscription } from 'rxjs/Subscription';
import { environment } from '../environments/environment';
let packagejson = require('../../package-lock.json');

@Component({
  selector: 'scm-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'Workforce Shell';
  private userSubscription: Subscription;
  private sysSubscription: Subscription;
  private user: User;
  highMessages: Message[] = [];
  lowMessages: Message[] = [];
  public activeSystem: System;
  private pgcoreVersion = packagejson.dependencies['pg-app-core'].version;
  private comcoreVersion = packagejson.dependencies['pg-com-core'].version;
  private workforceVersion = packagejson.dependencies['pg-scm-workforce'].version;

  constructor (private _userService: UserService, 
    private _comService: COMStateService,
    private _comMessageService: COMMessageService,
    private _pgConfigService: PGConfigService) {
  }

  ngOnInit() {
    const config = new UserServiceConfig();
    config.tenant = environment.tenant;
    config.baseHREF = environment.baseHref;
    config.clientId = environment.clientId;
    config.endpoints = environment.endpoints;
    this._userService.init(config);
    this.userSubscription = this._userService.user.subscribe(user => this.user = user);
    this.sysSubscription = this._comService.activeSystem.subscribe(sys => this.activeSystem = sys );

    this._pgConfigService.api_base.salesforce = environment.sfEndpoint;
    this._pgConfigService.api_base.workforce = environment.wfEndpoint;

    this._comMessageService.lowMsgs.subscribe(messages => { this.lowMessages = messages; });
    this._comMessageService.highMsgs.subscribe(messages => { this.highMessages = messages; });
  }

  ngOnDestroy() {
      if (this.userSubscription) { this.userSubscription.unsubscribe(); }
      if (this.sysSubscription) { this.sysSubscription.unsubscribe(); }
  }

  login() {
    this._userService.login();
  }

  logout() {
    this._userService.logout();
  }

  get isUserLoaded(): boolean {
    if (this.user) {
      return true;
    }
    return false;
  }

  get sfUserRoles() {
    return this.user.roles[environment.sfEndpoint];
  }

  get wfUserRoles() {
    return this.user.roles[environment.wfEndpoint];
  }
}
