export { WorkforceModule } from './workforce.module';
