 
export const activeRouterValue: any ={
  data: {
    subscribe: (fn: (value: any) => void) => fn({
       id: 1,
    }),
  },
  params: {
    subscribe: (fn: (value: any) => void) => fn({
      tab: 0,
    }),
  },
  snapshot: {
    routeConfig: {

    },
    path: '',
    queryParams: {
      id: 1
    },
    params: {
      id: "Morehead17"
    },
    url: [
      {
        path: 'facility/:id'
      }
    ],
  },
};