# PG SCM Workforce Plugin
This package contains UI components specific to configuring the Workforce service

# 1.0.2
* Changed routes to support lazy loading
