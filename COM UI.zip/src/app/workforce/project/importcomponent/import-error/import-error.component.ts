import { Component, OnInit, ViewChild } from '@angular/core';
import { ProjecthubParticipantComponent } from "../../projecthub.participant.component";
import { Table } from 'primeng/table';
import { ProjectDataService } from '../../../shared/project.data.service';
import { ImportDataService, Job } from '../../../shared/import.data.service';
import { COMMessageService, COMMessageSeverity } from 'pg-com-core';
@Component({
  selector: 'scm-import-error',
  templateUrl: './import-error.component.html',
  styleUrls: ['./import-error.component.css']
})
export class ImportErrorComponent implements OnInit {

  ErrGridSearch: String = "";
  errorsList: any = {};
  erjGridSearch: string;
  @ViewChild('errGridTbl')  errGridTbl: Table;
  cols: any[];
  constructor(
    private _projecthubParticipantComponent:ProjecthubParticipantComponent,
    private _projDataService: ProjectDataService,
    public _importDataService: ImportDataService,
    private _comMessageService: COMMessageService,
  ) { }

  ngOnInit() {
  }

  returnToImportProjects(){
    this._projecthubParticipantComponent.isParticipantsError(false);
  }

}
