import { ComponentFixture, TestBed } from "@angular/core/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ProjecthubParticipantComponent } from "../../projecthub.participant.component";
import { ImportErrorComponent } from "./import-error.component";

xdescribe("ImportErrorComponent", () => {
    let comp: ImportErrorComponent;
    let fixture: ComponentFixture<ImportErrorComponent>;

    beforeEach(() => {
        const projecthubParticipantComponentStub = {
            isParticipantsError: () => ({})
        };
        TestBed.configureTestingModule({
            declarations: [ ImportErrorComponent ],
            schemas: [ NO_ERRORS_SCHEMA ],
            providers: [
                { provide: ProjecthubParticipantComponent, useValue: projecthubParticipantComponentStub }
            ]
        });
        fixture = TestBed.createComponent(ImportErrorComponent);
        comp = fixture.componentInstance;
    });

    it("can load instance", () => {
        expect(comp).toBeTruthy();
    });

    describe("ngOnInit", () => {
        
    });

    describe("returnToImportProjects", () => {
        it("makes expected calls", () => {
            const projecthubParticipantComponentStub: ProjecthubParticipantComponent = fixture.debugElement.injector.get(ProjecthubParticipantComponent);
            spyOn(projecthubParticipantComponentStub, "isParticipantsError");
            comp.returnToImportProjects();
            expect(projecthubParticipantComponentStub.isParticipantsError).toHaveBeenCalled();
        });
    });

});
