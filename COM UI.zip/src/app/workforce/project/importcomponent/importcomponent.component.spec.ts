import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportcomponentComponent } from './importcomponent.component';

xdescribe('ImportcomponentComponent', () => {
  let component: ImportcomponentComponent;
  let fixture: ComponentFixture<ImportcomponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportcomponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportcomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
