import { Component, OnInit, AfterViewInit, ElementRef, Renderer2 } from '@angular/core';
import { DataTableModule } from 'primeng/primeng';
import { FileUpload, Message, Growl } from 'pg-primeng/primeng';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Project } from '../../shared/models/project.model';
import { ProjectDataService } from '../../shared/project.data.service';
import { ImportDataService, Job } from '../../shared/import.data.service';
import { ProjecthubComponent } from "../projecthub.component";
import { ProjecthubParticipantComponent } from "../projecthub.participant.component";
import { PGConfigService } from 'pg-app-core';
import { COMMessageService, COMMessageSeverity } from 'pg-com-core';

@Component({
  selector: 'scm-importcomponent',
  templateUrl: './importcomponent.component.html',
  styleUrls: ['./importcomponent.component.css']
})
export class ImportcomponentComponent implements OnInit, AfterViewInit {

  participants;
  participantstotalRecords;
  inputQuery;
  //importTemplate: WorkItemType;
  importTemplate;
  apiType = "";
  badFile = false;
  chooseBtn: any;
  cancelBtn: any;
  fileInput: any;
  prjGridSearch: string;
  lowMessages: Message[] = [];

  importList: Job[] = [];
  constructor(
    protected _router: Router,
    private _projDataService: ProjectDataService,
    public _importDataService: ImportDataService,
    private _pgConfigService: PGConfigService,
    private _comMessageService: COMMessageService,
    private _projecthubParticipantComponent:ProjecthubParticipantComponent,
    private _el: ElementRef,
    private _renderer: Renderer2
  ) { }

  ngOnInit() {
    this.refreshImports();
    this.apiType = `${this._pgConfigService.api_base.workforce}/v1/Projects/${this._projDataService.getActiveProject().projectId}/ParticipantImports`;
  }

  ngAfterViewInit() {
    //get handles to ui elements
    this.chooseBtn = this._el.nativeElement.querySelector('button.ui-fileupload-choose');
    this.cancelBtn = this._el.nativeElement.querySelector(".ui-fileupload-buttonbar button[label='Cancel']");
    this.fileInput = this._el.nativeElement.querySelector("input[type='file']");
  }

  onParticipantsUpload(event) {
    for(let file of event.files) {
        this._comMessageService.showLowMessage("File:  " + file.name + " has been uploaded.");
    }
    this.refreshImports();
  }

  refreshImports() {
    let proj = this._projDataService.getActiveProject();
    this._importDataService.getParticpantImportsByProject(proj.projectId).subscribe(
        response => {
          this.importList = response["jobs"];
         },
        error => {
            if (error.status === 404 && error.statusText === "Not Found") {
            }
            else {
              this._comMessageService.showHighMessage("An Error has occured while retrieving import history!", COMMessageSeverity.Error);
            }
        }
    );
}
  onSelect(event) {
    //Validations
    for (const file of event.files) {
      //invalid file type
      //BJP commented out the next file bc i didnt know what it was doing :-(
      //let file = event.files[0];

      const fileParts = file.name.split('.');
      const ext = fileParts[fileParts.length - 1];

      if (file.type === "" || "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet".indexOf(file.type) === -1 || ext.indexOf("xlsx") === -1) {
          this.badFile = true;
          //remove from the selected list
          setTimeout(() => {
              this.cancelBtn.click();
          }, 300);
      } else {
          this._renderer.removeAttribute(this.chooseBtn, "disabled");
          this._renderer.setAttribute(this.chooseBtn, "ng-reflect-disabled", "true");
          this.badFile = false;
      }
    }
  }

  onClear(){
    this.resetImport();
  }

  onError(event) {
    if (event.xhr.status === 401) {
      //this._message.showHighMessage("You are not authenticated to import files!", "error");
    } else {
      for (const file of event.files) {
          //this._message.showHighMessage("Error uploading file:  " + file.name, "error");

      }
    }
  }

  getImportErrors(job){
    let proj = this._projDataService.getActiveProject();  
    this._importDataService.getParticipantImportErrors(proj.projectId, job.id ).subscribe(
        response => {                   
          this._projecthubParticipantComponent.isParticipantsError(true);
        },
        error => {
            if (error.status === 404 && error.statusText === "Not Found") {
            }
            else {
              this._comMessageService.showHighMessage("An Error has occured while retrieving import error list!", COMMessageSeverity.Error);
            }
        }
    );
  }

  resetImport() {
    this.importTemplate = null;
    this._renderer.removeAttribute(this.chooseBtn, "disabled");
    this._renderer.setAttribute(this.chooseBtn, "ng-reflect-disabled", "true");
    this._renderer.removeAttribute(this.fileInput, "disabled");
  }
}
