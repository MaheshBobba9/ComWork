import { TestBed, inject } from '@angular/core/testing';
import { Injectable } from '@angular/core';
import { Project } from './models/project.model';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { COMStateService } from 'pg-com-core';
import { PGConfigService } from 'pg-app-core';
import { ProjectDataService } from './project.data.service';
import { Mock } from 'protractor/built/driverProviders';

export class MockCOMStateService {}
export class MockHttpClient {}

let mockCOMStateService: MockCOMStateService;
let mockHttpClient: MockHttpClient;

describe('ProjectDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProjectDataService,  PGConfigService,
      {provide: COMStateService, useClass: MockCOMStateService},
      {provide: HttpClient, useClass: MockHttpClient}]
    });
  });

  it('should be created', inject([ProjectDataService], (service: ProjectDataService) => {
    expect(service).toBeTruthy();
  }));
});
