import { Injectable } from '@angular/core';
import { Project } from './models/project.model';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/share';
import { COMStateService } from 'pg-com-core';
import { PGConfigService } from 'pg-app-core';
 
@Injectable()
export class ProjectDataService {
  HttpHeadersData: any;
  private headers: HttpHeaders;
  private options = { observe: 'response' as 'response', headers: this.headers };

  private _projects: BehaviorSubject<Project[]> = new BehaviorSubject([]);
  public projects: Observable<Project[]> = this._projects.asObservable();

  private _project: BehaviorSubject<Project> = new BehaviorSubject(null);
  public project: Observable<Project> = this._project.asObservable();
  public jobErrors:any = [];
  constructor( 
    private _comStateService: COMStateService,
    private _http: HttpClient,
    private _pgConfigService: PGConfigService
  ) { }
  
  getProjectsBysystem(systemId: string): Observable<HttpResponse<Project[]>>{
    return this._http.get<Project[]>(`${this._pgConfigService.api_base.workforce}/v1/projects?systemid=${systemId}`, this.options).share();
  }

  setActiveProject(project: Project){
       this._project.next(project);
  }

  getActiveProject(): Project{
    return <Project>this._project.getValue();
  }

  public getParticipantsByProject(projectId: string, pageSize: number, pageNumber: number, sortCol: string = "name", sortOrder:number, searchTxt:string): Observable<any> {
    return this._http.get(`${this._pgConfigService.api_base.workforce}/v1/participants?projectId=${projectId}&pageSize=${pageSize}&pageNumber=${pageNumber}&sortCol=${sortCol}&sortOrder=${sortOrder}&searchTxt=${searchTxt}`, this.options).share();
  }

}
