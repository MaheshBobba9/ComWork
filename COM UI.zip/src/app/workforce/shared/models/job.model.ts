export class Job {
    public Id: string;
    public JobType: string;
    public SF_AccountId: string;
    public  ProjectId: string;
    public UserName: string;
    public  Status: string;
    public Started : string;
    public Ended : string;
    public WorkingFileLocation: string;
    public UploadFileLocation: string;
    public ArchiveFileLocation: string;
    public ParticipantRecordsWritten: number;
}
