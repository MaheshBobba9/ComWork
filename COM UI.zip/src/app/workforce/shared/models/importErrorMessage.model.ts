import { Job } from '../../shared/models/job.model';

export class ImportErrorMessage {
    public Id: string;
    public LineNumber: number;
    public ErrorMesssage: string;
    public Job: Job;
    
}
