
export class Participants {
    constructor(){
        this.nodeId = "";
        this.sourceId = "";
        this.firstName = "";
        this.middleName = "";
        this.lastName = "";
        this.email = "";
        this.lastUpdatedDate = "";
    }

    public nodeId: string;
    public sourceId: string;
    public firstName: string;
    public middleName: string;
    public lastName: string;
    public email: string;
    public lastUpdatedDate: string;
       
    deserialize(input){
        if (input === undefined || input === null) return null;

        this.nodeId = input.nodeId;
        this.sourceId = input.sourceId;
        this.firstName = input.firstName;
        this.middleName = input.middleName;
        this.lastName = input.lastName;
        this.email = input.email;
        this.lastUpdatedDate = input.lastUpdatedDate;
        return this;
    }
}