
export class Hierarchy {
    constructor(){
        this.name="";
        this.type="";
        this.primary="";
        this.numberOfMembers= 0;
        this.lastUpdatedDte="";

    }

    public name : string;
    public type : string;
    public primary : string ;
    public numberOfMembers : number;
    public lastUpdatedDte : string;
       
    deserialize(input){
        if (input === undefined || input === null) return null;

        this.name = input.name;
        this.type = input.type;
        this.primary = (input.primary === true)? "Y" : "N";
        this.numberOfMembers = input.numberOfMembers;
        this.lastUpdatedDte = input.lastUpdatedDte;
        return this;
    }
}