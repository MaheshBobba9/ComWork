
export class Project {
    constructor(){
        this.projectName = "";
        this.projectId = "";
        this.lastUpdatedDate = "";
        this.adminStartDate = "";
        this.status = "";

    }

    public projectId: string;
    public projectName: string;
    public adminStartDate: string;
    public status: string;
    public lastUpdatedDate: string;
       
    deserialize(input){
        if (input === undefined || input === null) return null;

        this.projectId = input.projectId;
        this.projectName = input.projectName;
        this.adminStartDate = input.adminStartDate;
        this.status = input.status;
        this.lastUpdatedDate = input.lastUpdatedDate;
        return this;
    }
}