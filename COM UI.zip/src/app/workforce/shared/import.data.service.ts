import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/share';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Job } from '../shared/models/job.model';

import { COMStateService } from 'pg-com-core';
import { PGConfigService } from 'pg-app-core';
import { ImportErrorMessage } from '../shared/models/importErrorMessage.model';

@Injectable()
export class ImportDataService {
    private _importJobs: BehaviorSubject<Job[]> = new BehaviorSubject([]);
    public importList: Observable<Job[]> = this._importJobs.asObservable();

    private _importErrors: BehaviorSubject<ImportErrorMessage[]> = new BehaviorSubject([]);
    public importErrors: Observable<ImportErrorMessage[]> = this._importErrors.asObservable();    

    constructor(private _http: HttpClient, 
      private _pgConfigService: PGConfigService,
      private _comStateService: COMStateService) {
        //When active system changes, we need to clear out system-specific data
        // this._comStateService.activeSystem.subscribe(
        //     system => {
        //         this._workItems.next([]);
        //     }
        // );
    }

    public getParticpantImportsByProject(projectId: string): Observable<any> {
        const obs = this._http.get(`${this._pgConfigService.api_base.workforce}/v1/Projects/${projectId}/ParticipantImports`).share();

        obs.subscribe(
            data => {
                let jobList = <Job[]>data["jobs"];
                this._importJobs.next(jobList);
            }, error => { }
        );

        return obs;
    }
    public getParticipantImportErrors(projectId: string, participantImportId: string): Observable<any> {
        const obs = this._http.get(`${this._pgConfigService.api_base.workforce}/v1/Projects/${projectId}/ParticipantImports/${participantImportId}/Errors`).share();

        obs.subscribe(
            data => {
                let errorMessagesList = <ImportErrorMessage[]>data["errorMessages"];
                this._importErrors.next(errorMessagesList);
            }, error => { }
        );

        return obs;
    }

    // public downloadImportErrorsExcel(workItemId: string){
    //     return this._downloadService.getFile(`/workitems/${workItemId}/errors`, DownloadService.ExcelContentType).subscribe();
    // }    
}

export { Job };
