import { TestBed, inject } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { ImportDataService } from './import.data.service';
import { COMStateService } from 'pg-com-core';
import { PGConfigService } from 'pg-app-core';

export class MockCOMStateService {}
export class MockHttpClient {}

let mockCOMStateService: MockCOMStateService;
let mockHttpClient: MockHttpClient;

describe('Import.DataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ImportDataService, PGConfigService,
        {provide: COMStateService, useClass: MockCOMStateService},
        {provide: HttpClient, useClass: MockHttpClient}]
    });
  });

  it('should be created', inject([ImportDataService], (service: ImportDataService) => {
    expect(service).toBeTruthy();
  }));
});
