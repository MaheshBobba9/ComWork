import { Injectable } from '@angular/core';
import { Hierarchy } from './models/hierarchy.model';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/share';
import { COMStateService } from 'pg-com-core';
import { PGConfigService } from 'pg-app-core';
 
@Injectable()
export class HierarchyDataService {
  private headers: HttpHeaders;
  private options = { observe: 'response' as 'response', headers: this.headers };

  private _Hierarchies: BehaviorSubject<Hierarchy[]> = new BehaviorSubject([]);
  public Hierarchies: Observable<Hierarchy[]> = this._Hierarchies.asObservable();

  constructor( 
    private _comStateService: COMStateService,
    private _http: HttpClient,
    private _pgConfigService: PGConfigService
  ) { }
  
  getReportingGroups(projectId: String): Observable<HttpResponse<Hierarchy[]>>{
    return this._http.get<Hierarchy[]>(`${this._pgConfigService.api_base.workforce}/v1/reportinggroups?projectId=${projectId}`, this.options).share();
  } 

}
