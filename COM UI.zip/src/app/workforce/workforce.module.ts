import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule }  from '@angular/common';
import { WorkforceRoutingModule } from './workforce-routing.module';
import { ProjectComponent } from './project/project.component';
import { TableModule }  from 'primeng/table';
//import { TabViewModule, TabView }  from 'primeng/tabview';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProjectDataService } from './shared/project.data.service';
import { HierarchyDataService } from './shared/hierarchy.data.service';
import { ProjecthubComponent } from './project/projecthub.component';
import { ProjecthubParticipantComponent } from './project/projecthub.participant.component';
import { ProjecthubHierarchyComponent } from './project/projecthub.hierarchy.component';
import { FileUploadModule, MenuModule, DataTableModule, PaginatorModule, GrowlModule, TabViewModule } from 'pg-primeng/primeng';
import { ImportcomponentComponent } from './project/importcomponent/importcomponent.component';
//import { FileUploadModule } from 'primeng/fileupload';
import { ImportErrorComponent } from './project/importcomponent/import-error/import-error.component';
import { ImportDataService } from './shared/import.data.service';


@NgModule({
    imports: [RouterModule, WorkforceRoutingModule, TableModule, TabViewModule, FormsModule, CommonModule, 
              MenuModule, FileUploadModule, DataTableModule, PaginatorModule, GrowlModule],
    declarations: [ ProjectComponent, ProjecthubComponent, ProjecthubParticipantComponent, ProjecthubHierarchyComponent, ImportcomponentComponent, ImportErrorComponent ],
    providers: [ProjectDataService,HierarchyDataService, ImportDataService]
})

export class WorkforceModule {}
