import { Component, OnInit, OnDestroy, Injectable, NO_ERRORS_SCHEMA } from '@angular/core';
import { TestBed, async } from '@angular/core/testing';
import {RouterTestingModule} from '@angular/router/testing';
import { Message } from 'pg-primeng/primeng';
import { COMMessageService, COMMessageSeverity} from 'pg-com-core';
import { AppComponent } from './app.component';
import { UserService, UserServiceConfig, User, PGConfigService } from 'pg-app-core';
import { COMStateService, System } from 'pg-com-core';
import { environment } from '../environments/environment';
import { AppModule } from './app.module';
import { defer } from 'rxjs/observable/defer';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class MockPgConfigService {}
export class MockCOMStateService {}
export class MockCOMMessageService {}

@Injectable()
export class MockedUsersService  {
  user: Observable<any>;
  constructor() {
    let mockedUser = {"id": 60,
    "name": "Test User1",
    getRoles: function(env: string): string[] {
      return ['admin', 'user'];
    }
    };
    this.user = defer(() => Promise.resolve(mockedUser));
  }

  init(config: UserServiceConfig ): void{}
}

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        {provide: UserService, useClass: MockedUsersService},
        {provide: COMStateService, useClass: MockCOMStateService},
        {provide: COMMessageService, useClass: MockCOMMessageService},
        {provide: PGConfigService, useClass: MockPgConfigService}
      ],
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  }));
  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
  it(`should have as title 'Workforce Shell'`, async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('Workforce Shell');
  }));
  xit('should render title in a h1 tag', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('Welcome to app!');
  }));
});
