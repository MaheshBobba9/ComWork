import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { PGCoreModule } from 'pg-app-core';
import { COMCoreModule } from 'pg-com-core';
import { MessagesModule, GrowlModule } from 'pg-primeng/primeng';
//import { WorkforceModule } from 'pg-scm-workforce';
import { SystemModule } from './system/system.module';
import { SCMSharedModule } from './shared/shared.module';
//import { SFDataService } from "./shared/sf/sfdata.service";

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule, BrowserAnimationsModule, MessagesModule, GrowlModule, PGCoreModule.forRoot(), COMCoreModule.forRoot(), SCMSharedModule.forRoot(),
    SystemModule, AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
