import { NgModule } from "@angular/core";
import { WorkforceModule } from 'pg-scm-workforce';

@NgModule({
    imports: [
        WorkforceModule
    ]
  })
  export class WorkforceLazyLoader {}