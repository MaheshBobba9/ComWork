import { NgModule }             from '@angular/core';
import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
//import { SlimLoadingBarModule } from 'ng2-slim-loading-bar';
import { HttpClientModule } from '@angular/common/http';

//import { BoolLabelPipe }        from './boolLabel.pipe';
//import { CapitalizePipe }       from './capitalize.pipe';
//import { CustomDateFormatPipe }       from './customdateformat.pipe';
//import { TruncatedStringOverlayComponent } from './truncatedStringOverlay.component';
//import { HasRoleAccessDirective }   from './hasRoleAccess.directive';
//import { HasAllRoleAccessDirective }   from './hasAllRoleAccess.directive';
import { ModuleWithProviders } from '@angular/compiler/src/core';
//import { BaseComponent } from './base.component';

//import { CanActivateGuard, CanDeactivateGuard } from './componentguard.service';
//import { DownloadService } from './download.service';
//import { EntityEventDataService } from './com/entityeventdata.service';
//import { FacilityDataService } from './com/facilitydata.service';
//import { FacilityServiceDataService } from './com/facilityservicedata.service';
//import { MessageService } from './message.service';
//import { UtilityService } from './utility.service';
//import { ProviderDataService } from './com/providerdata.service';
import { SFDataService } from './sf/sfdata.service';
//import { ServiceDataService } from './com/servicedata.service';
//import { FssDataService } from './com/fssdata.service';
//import { ConfirmationService } from 'pg-primeng/primeng';
//import { ReportHierarchyDataService } from './com/reporthierarchydata.service';
//import { LoadingBarInterceptor } from './loadingbar-interceptor';
//import { AppInsightsInterceptor } from './appinsights-interceptor';
//import { ApplicationInsightsModule, AppInsightsService } from '@markpieszak/ng-application-insights';
//import { environment } from '../../environments/environment';
//import { COMMessageDataService } from './com/commessagedata.service';
//import { HttpProgressService } from './http-progress.service';
//import { ModalOverlayComponent } from './modal-overlay/modal-overlay.component';

@NgModule({
    imports: [ HttpClientModule, CommonModule ],
    declarations: [ ],
    exports: [ ]
})

export class SCMSharedModule {
    public static forRoot(): ModuleWithProviders {
        return {
            ngModule: SCMSharedModule,
            providers: [ SFDataService ]
        };
    }
}
