import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/share';
import { System } from 'pg-com-core';
//import { ContractHierarchy } from './models/contracthierarchy.model';
import { Client } from '../sf/models/client.model';
import { Service } from '../sf/models/service.model';
import { environment } from '../../../environments/environment';
import { COMStateService } from 'pg-com-core';
import { PGConfigService } from "pg-app-core";

@Injectable()
export class SFDataService {
    private headers: HttpHeaders;
    private options = { observe: 'response' as 'response', headers: this.headers };

    constructor(private _http: HttpClient, private _comStateService: COMStateService, private _pGConfigService: PGConfigService) {
        this.headers = new HttpHeaders();
        this.headers.append('Content-Type', 'application/json');
        this.headers.append('Accept', 'application/json');
    }

    public getAll(pageNumber: number = 0, pageSize: number = 0, sortCol: string = "name", sortOrder: number = 0, search: string = ""): Observable<any> {
        return this._http.get(`${this._pGConfigService.api_base.salesforce}/v2/clients?pageNumber=${pageNumber}&pageSize=${pageSize}&sortCol=${sortCol}&sortOrder=${sortOrder}&searchTerm=${search}`).share();
    }
    
}

export { System, Client, Service };
//export { System, ContractHierarchy, Client, Service };