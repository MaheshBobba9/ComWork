import { Client } from "./client.model";
import { System } from "pg-com-core";

export class Service{
    id: string;
    name: string;
    status: string;
    number: string;
    client: Client;
    system: System;

    isAssignedToFacility: boolean;
}