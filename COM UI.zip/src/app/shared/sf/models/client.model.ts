import { System } from "pg-com-core";

export class Client{
    id: string;
    name: string;
    status: string;
    pgClientId: string;
    clientType: string;
    city: string;
    state: string;
    system: System;
    isAssigned: boolean;

}