import { Component, OnInit, OnDestroy, Injectable, ViewChild, Input } from '@angular/core';
import {DataTableModule, LazyLoadEvent} from 'primeng/primeng';
import { Router, NavigationExtras } from '@angular/router';
//import { SFDataService, System, Client } from '../shared/sf/sfdata.service';
import { SFDataService, Client } from "../shared/sf/sfdata.service";
import { UserService, UserServiceConfig, User } from 'pg-app-core';
import { COMStateService, System } from 'pg-com-core';
import { Project } from '../workforce/shared/models/project.model';
import { ProjectDataService } from '../workforce/shared/project.data.service';
import { DataTable } from 'pg-primeng/primeng';
import { Subscription } from 'rxjs/Subscription';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { environment } from '../../environments/environment';
import { timeout } from 'q';

@Component({
  selector: 'scm-system',
  templateUrl: './system.component.html',
  styleUrls: ['./system.component.css']
})
export class SystemComponent implements OnInit, OnDestroy {
    
    clientGridSearch: string;
    loading: boolean;
    cols: any[];
    totalNumberOfClients: number;
    msgs: string[] = [];
    highLevelMessages: BehaviorSubject<string[]> = new BehaviorSubject<string[]>([]);
    highLevelMessageSeverity = "info";
    clientList: Client[] = [];    
    activeUserSubscription: Subscription;
    activeUser: User;
    @ViewChild("sysGridTbl") sysGrid: DataTable;
    constructor(  
        private _sysData: SFDataService, 
        protected router: Router,  
        private _userService: UserService,
        private _comStateService: COMStateService ) { 

        }
        ngOnInit() {
            //this.loading = true;
            this.activeUserSubscription = this._userService.user.subscribe(user => {
                this.activeUser = user;
            });
            this.cols = [
                {field: 'pgClientId', header: 'PG ClientID'},
                {field: 'clientType', header: 'Type'},
                {field: 'name', header: 'Name'},
                {field: 'status', header: 'Status'},
                {field: 'city', header: 'City'},
                {field: 'state', header: 'State'}
            ];
        }

        loadClientsLazy(event: LazyLoadEvent) {
            let pg = event.first;
            if(pg > 0) pg = pg / 10;
            setTimeout(() => {
                this._sysData.getAll(pg, event.rows, event.sortField, event.sortOrder, this.sysGrid.globalFilter.value).subscribe(
                    response => {
                        const responseJSON = response;
                        this.clientList = [];
                        Object.assign(this.clientList, <Client[]>responseJSON.clients);
                        this.totalNumberOfClients = responseJSON.totalNumberOfClients;
                    },
                    error => {
                        if (error.status === 404 && error.statusText === "Not Found") {
                            this.clientList = [];
                            this.totalNumberOfClients = 0;
                        }else{                
                            this.highLevelMessageSeverity = "error";
                            this.msgs.push("An Error has occured while retrieving systems!");
                            this.highLevelMessages.next(this.msgs);
                        }
                    }
                );
            });
        }
        ngOnDestroy(){
            if (this.activeUserSubscription) { this.activeUserSubscription.unsubscribe(); }
        }

        onRowSelect(event) {
            console.log(event);
            this._comStateService.setActiveSystem(event.data.system);
            const navigationExtras: NavigationExtras = {
                queryParams: {
                    "sys": this._comStateService.getActiveSystem().id
                }
            };

            if (this.activeUser.hasRole(environment.sfEndpoint, "ViewServices"))
                this.router.navigate(["scm-workforce/projects"], navigationExtras);
            //else if (this.activeUser.hasRole(environment.comEndpoint, "ManageGroup"))
                //this.router.navigate(["customgroups"], navigationExtras);
            else 
                console.log("You do not have the proper roles to navigate to a landing page.");
        }

        canViewSystems(): boolean {
            if(this.activeUser === null) return false;
            return this.activeUser.hasRole(environment.sfEndpoint, 'ViewSystems');
        }

}
