import { NgModule }                 from '@angular/core';
import { CommonModule }             from '@angular/common';
import { RouterModule }             from '@angular/router';
//import { DataTableModule, 
//         InputTextModule, 
//         PaginatorModule}          from 'pg-primeng/primeng';
import {PaginatorModule, 
        DataTableModule}            from 'pg-primeng/primeng';
import { SystemComponent }          from './system.component';
import { SystemRoutingModule }      from './system-routing.module';
import { SFDataService }            from "../shared/sf/sfdata.service";
import { ProjectDataService } from   '../workforce/shared/project.data.service';
import { HierarchyDataService } from '../workforce/shared/hierarchy.data.service';
//import { TableModule, Table }  from 'primeng/table';

@NgModule({
    //imports:        [ CommonModule, RouterModule, DataTableModule, InputTextModule, PaginatorModule, SystemRoutingModule ],
    imports:        [ CommonModule, 
                      RouterModule, 
                      SystemRoutingModule,
                      DataTableModule,
                      PaginatorModule
                     ],
    declarations:   [ SystemComponent ],
    providers:      [SFDataService, ProjectDataService,HierarchyDataService],
})

export class SystemModule{}