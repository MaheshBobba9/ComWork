import { NgModule }             from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import { CanActivateGuard }     from '../shared/componentguard.service';
import { SystemComponent }      from './system.component';
import { environment }          from '../../environments/environment';
import { UserRoleQuery }        from 'pg-app-core';

const systemRouteData = new UserRoleQuery();
systemRouteData.resource = environment.sfEndpoint;
systemRouteData.roles = ["ViewSystems"];
systemRouteData.hasAnyRoles = true;

const routes: Routes = [
    //{ path: 'systems', component: SystemComponent, canActivate: [CanActivateGuard], data: systemRouteData }
    { path: 'systems', component: SystemComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class SystemRoutingModule{}